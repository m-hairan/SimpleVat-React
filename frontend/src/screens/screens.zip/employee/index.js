import screen from './screen'
import * as actions from './actions'
import reducer from './reducer'

export default {
  screen,
  actions,
  reducer
}