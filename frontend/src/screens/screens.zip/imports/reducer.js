import { IMPORTS } from 'constants/types'

const initState = {
}

const ImportsReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default ImportsReducer