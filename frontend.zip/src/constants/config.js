export default {
  API_ROOT_URL: 'http://k8s.dev.simplevat.com/'
}
