import InitialLayout from './initial'
import AdminLayout from './admin'

export {
  InitialLayout,
  AdminLayout
}