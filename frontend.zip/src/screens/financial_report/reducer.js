import { TEMP } from 'constants/types'

const initState = {
}

const TempReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default TempReducer