import { CHART_ACCOUNT } from 'constants/types'

const initState = {
}

const ChartAccountReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default ChartAccountReducer