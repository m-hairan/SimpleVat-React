import { CHART_ACCOUNT } from 'constants/types'
import {
  api,
  authApi
} from 'utils'

export const initialData = () => {
  return (dispatch) => {
    
  }
}
