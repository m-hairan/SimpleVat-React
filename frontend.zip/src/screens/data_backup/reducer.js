import { DATA_BACKUP } from 'constants/types'

const initState = {
}

const DataBackupReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default DataBackupReducer