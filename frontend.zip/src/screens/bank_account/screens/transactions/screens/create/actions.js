import { BANK_ACCOUNT } from 'constants/types'
import {
  api,
  authApi
} from 'utils'

export const initialData = () => {
  return (dispatch) => {
    
  }
}
