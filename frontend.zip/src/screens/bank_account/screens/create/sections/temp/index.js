import React from 'react'

import './style.scss'

class Temp extends React.Component {
  
  constructor(props) {
    super(props)
    this.state = {
    }

  }

  render() {

    return (
      <div className="temp-section">
        <div className="animated fadeIn">
          
        </div>
      </div>
    )
  }
}

export default Temp


