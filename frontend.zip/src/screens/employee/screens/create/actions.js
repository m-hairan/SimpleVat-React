import { EMPLOYEE } from 'constants/types'
import {
  api,
  authApi
} from 'utils'

export const initialData = () => {
  return (dispatch) => {
    
  }
}
