import { HELP } from 'constants/types'

const initState = {
}

const HelpReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default HelpReducer