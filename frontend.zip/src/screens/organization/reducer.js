import { ORGANIZATION } from 'constants/types'

const initState = {
}

const OrganizationReducer = (state = initState, action) => {
  const { type, payload} = action
  
  switch(type) {

    default:
      return state
  }
}

export default OrganizationReducer