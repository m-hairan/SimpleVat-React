import mainRoutes from './main'
import initialRoutes from './initial'
import adminRoutes from './admin'

export {
  mainRoutes,
  initialRoutes,
  adminRoutes
}